# resources

This folder contains resources that we will use throughout the day.
