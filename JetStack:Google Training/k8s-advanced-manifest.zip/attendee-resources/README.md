# Kubernetes resources

This folder contains some resources that we will use throughout the day.
